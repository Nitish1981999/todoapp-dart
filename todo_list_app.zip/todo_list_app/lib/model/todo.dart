
class ToDo{
  String? id;
  String? todoText;
  bool isDone;
  ToDo({
    required this.id,
    required this.todoText,
    this.isDone=false,

  });
  static List<ToDo>todoList(){
    return [
      ToDo(id:'01',todoText: 'Morning Exercise',isDone:true),
      ToDo(id:'02',todoText: 'Take a bath',isDone:true),
      ToDo(id:'03',todoText: 'Get ready',),
      ToDo(id:'04',todoText: 'Breakfast',),
      ToDo(id:'05',todoText: 'Go to office',),
      ToDo(id:'06',todoText: 'work',),

    ];
  }

}// TODO Implement this library.